<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Header -->
    <section class="bg-slate-950 text-white py-14 lg:py-16 border-b border-slate-900 industrial-grid-dark relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="max-w-3xl">
                <span class="text-xs font-bold text-amber-400 uppercase tracking-wider bg-slate-900 border border-slate-800 px-3 py-1 rounded-full">
                    Heavy Machinery Spares & Wear Parts
                </span>
                <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black text-white mt-3">
                    Construction Equipment & Replacement Spares
                </h1>
                <p class="text-slate-300 text-sm sm:text-base mt-2">
                    Batching plant wear liners, concrete pump tungsten carbide wear plates, transit mixer spiral drums, and Rexroth hydraulics in stock at our Jaipur facility.
                </p>
            </div>
        </div>
    </section>

    <!-- Filter & Product Catalog -->
    <section class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <!-- Category Tabs & Search Bar -->
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <!-- Tabs -->
                <div class="flex items-center space-x-1.5 overflow-x-auto pb-2 md:pb-0 text-xs sm:text-sm font-semibold">
                    <a href="<?php echo e(route('products')); ?>" class="px-3.5 py-2 rounded-lg transition whitespace-nowrap <?php echo e(!request('category') ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-100'); ?>">
                        All Equipment
                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products', ['category' => $category->slug])); ?>" class="px-3.5 py-2 rounded-lg transition whitespace-nowrap <?php echo e(request('category') === $category->slug ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-100'); ?>">
                            <?php echo e($category->name); ?> (<?php echo e($category->products_count); ?>)
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Search Input -->
                <form action="<?php echo e(route('products')); ?>" method="GET" class="relative shrink-0 w-full md:w-72">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('category')): ?>
                        <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search model, SKU, parts..." class="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                    <svg class="w-4 h-4 text-slate-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                </form>
            </div>

            <!-- Active Category Banner if filtered -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedCategory): ?>
                <div class="mb-8 p-5 rounded-xl bg-blue-50 border border-blue-200/70 text-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                        <h2 class="text-lg font-bold text-blue-900"><?php echo e($selectedCategory->name); ?></h2>
                        <p class="text-xs text-slate-600 mt-1 max-w-2xl"><?php echo e($selectedCategory->description); ?></p>
                    </div>
                    <a href="<?php echo e(route('products')); ?>" class="text-xs font-bold text-blue-700 hover:underline shrink-0">
                        Clear Filter &times;
                    </a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <!-- Products Grid -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($products->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group">
                            <div class="p-6">
                                <div class="flex items-center justify-between gap-2 mb-3">
                                    <span class="px-2.5 py-1 rounded text-xs font-bold bg-slate-100 text-slate-700 uppercase tracking-wider">
                                        <?php echo e($product->category->name); ?>

                                    </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->sku): ?>
                                        <span class="font-mono text-xs text-slate-500 font-semibold"><?php echo e($product->sku); ?></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <h3 class="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition mb-2">
                                    <a href="<?php echo e(route('products.detail', $product->slug)); ?>">
                                        <?php echo e($product->name); ?>

                                    </a>
                                </h3>

                                <p class="text-slate-600 text-xs leading-relaxed mb-4 line-clamp-3">
                                    <?php echo e($product->short_description); ?>

                                </p>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($product->specifications)): ?>
                                    <div class="bg-slate-50 rounded-lg p-3 text-xs space-y-1.5 border border-slate-100 mb-4">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = array_slice($product->specifications, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specKey => $specVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex justify-between items-center text-slate-600">
                                                <span class="font-semibold text-slate-500"><?php echo e($specKey); ?>:</span>
                                                <span class="text-slate-900 font-mono"><?php echo e($specVal); ?></span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                                <span class="text-xs font-bold text-amber-700"><?php echo e($product->brand ?: 'DC Equipment OEM'); ?></span>
                                <a href="<?php echo e(route('products.detail', $product->slug)); ?>" class="inline-flex items-center text-xs font-bold text-blue-700 hover:text-blue-900">
                                    <span>Technical Specs</span>
                                    <svg class="w-3.5 h-3.5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Pagination -->
                <div class="mt-12">
                    <?php echo e($products->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-600">
                    <p class="text-base font-semibold">No equipment spares matching your query were found.</p>
                    <p class="text-xs text-slate-500 mt-1">Please call our Jaipur desk at +91 86969 62600 for custom fabrication or unlisted part numbers.</p>
                    <a href="<?php echo e(route('products')); ?>" class="mt-4 inline-block px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold">
                        Reset Filters
                    </a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <!-- Quote Request Callout -->
            <div class="mt-20">
                <?php if (isset($component)) { $__componentOriginalb46848292f41c207996399fc87b6e67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb46848292f41c207996399fc87b6e67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quote-form','data' => ['title' => 'Inquire About Specific Part Numbers or Custom Fabrication','subtitle' => 'Our technical spare parts specialists can match OEM drawings for Putzmeister, Schwing Stetter, Sicoma, BHS, Sany, and Zoomlion.','defaultType' => 'equipment']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quote-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Inquire About Specific Part Numbers or Custom Fabrication','subtitle' => 'Our technical spare parts specialists can match OEM drawings for Putzmeister, Schwing Stetter, Sicoma, BHS, Sany, and Zoomlion.','defaultType' => 'equipment']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb46848292f41c207996399fc87b6e67b)): ?>
<?php $attributes = $__attributesOriginalb46848292f41c207996399fc87b6e67b; ?>
<?php unset($__attributesOriginalb46848292f41c207996399fc87b6e67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb46848292f41c207996399fc87b6e67b)): ?>
<?php $component = $__componentOriginalb46848292f41c207996399fc87b6e67b; ?>
<?php unset($__componentOriginalb46848292f41c207996399fc87b6e67b); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\dc equipment\resources\views/pages/products.blade.php ENDPATH**/ ?>